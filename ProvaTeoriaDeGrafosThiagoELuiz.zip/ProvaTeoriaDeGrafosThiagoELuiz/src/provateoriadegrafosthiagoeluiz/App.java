/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package provateoriadegrafosthiagoeluiz;

/**
 *
 * @author thiag
 */
    public class App {
    public static void main(String[] args) {
        int[][] matriz = {
            {0,1,1},
            {1,0,1},
            {1,1,0}
        };

        Grafo g = new Grafo(matriz);

        System.out.println("1) Tipo do grafo:");
        System.out.println(g.tipoDoGrafo());
        System.out.println();

        System.out.println("2) Arestas do grafo:");
        System.out.println(g.arestasDoGrafo());
        System.out.println();

        System.out.println("3) Graus dos vértices:");
        System.out.println(g.grausDoVertice());
        System.out.println();

        System.out.println("4) Busca em profundidade:");
        System.out.println(g.buscaEmProfundidade());
    }
}